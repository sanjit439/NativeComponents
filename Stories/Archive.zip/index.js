import React from 'react';
import { StyleSheet, Text, View, Image, Dimensions, TouchableWithoutFeedback,StatusBar } from 'react-native';
import Tab from './Tab';
import InfoSection from './InfoSection';

export default class App extends React.Component {
  constructor(props) {
    super(props);
    const screenDimension = Dimensions.get('window');
    this.screen = {
      width: screenDimension.width,
      height: screenDimension.height
    };
    this.inTime=0;
    this.outTime=0;
  
    
    this.state = {
      images: [
        "https://images.unsplash.com/photo-1523980230739-b0cb3d10ecd0?ixlib=rb-1.2.1&auto=format&fit=crop&w=666&q=80",
        "https://images.unsplash.com/photo-1499442428429-d6a1c9354cf8?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80",
        "https://images.unsplash.com/photo-1515091943-9d5c0ad475af?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=750&q=80",
        "https://images.unsplash.com/photo-1558545215-bbd7a9bff2b0?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=1650&q=80",
        "https://images.unsplash.com/photo-1559142642-915959bfac3e?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80",
        "https://images.unsplash.com/photo-1559139011-7ecdc76280aa?ixlib=rb-1.2.1&auto=format&fit=crop&w=750&q=80"
      ],
      active: 0,
      isAnimationStopped: true
    };


    this.next = this.next.bind(this);
    this.handlePressIn = this.handlePressIn.bind(this);
    this.handlePressOut = this.handlePressOut.bind(this);
  }


  static navigationOptions = {
    header: null
  };
  componentDidMount(){
    StatusBar.setHidden(true);
    }
  componentWillUnmount() {
    StatusBar.setHidden(false);
  }
  handlePressIn() {
    this.inTime=Date.now();
    this.setState( {
      isAnimationStopped: true
    });
  }

  handlePressOut() {

    this.outTime=Date.now();
    const diff=this.outTime-this.inTime;
    
     if(diff>150)
     {
      this.setState( {
        isAnimationStopped: false
      });
     }
     else 
     {
      this.setState({active:this.state.active+1,isAnimationStopped: true})
     }
    
    
  }
  loadingDone=()=>{
    this.setState({isAnimationStopped: false})
  }

  next() {
    const { active } = this.state;
    this.setState({
      active: active + 1,isAnimationStopped: true
    });
  }

  render() {
    const { images, active, isAnimationStopped } = this.state;

    return (
      <View style={styles.container}>
        
        <TouchableWithoutFeedback onPressIn={this.handlePressIn} onPressOut={this.handlePressOut}>
          <Image
            source={{ uri: images[active]}}
            resizeMode="cover"
            style={styles.image}
            onLoadEnd={this.loadingDone}
          ></Image>
        </TouchableWithoutFeedback>
        <View style={styles.tabContainer}>
          { images.map((image, index) => {
            return (
              <Tab key={index}  isActive={index === active } activeIndex={active} index={index} next={this.next} isAnimationStopped={isAnimationStopped}></Tab>
            );
          })}
        </View>
        <InfoSection/>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#000',
    
  },
  tabContainer: {
    flexDirection: "row",
    justifyContent: "space-evenly",
    backgroundColor:'transparent',
    position:'absolute',
    top:0,
    width:'100%',
    zIndex:1,
    paddingTop:10
  },
  image: {
    borderRadius: 4,
    height:'100%',
    width:'100%'
  },
  text: {
    color: '#fff',
  }
});
